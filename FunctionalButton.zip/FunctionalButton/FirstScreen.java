//package io.github.AngryBirds;
//
//import com.badlogic.gdx.Screen;
//
///** First screen of the application. Displayed after the application is created. */
//public class FirstScreen implements Screen {
//    @Override
//    public void show() {
//        // Prepare your screen here.
//    }
//
//    @Override
//    public void render(float delta) {
//        // Draw your screen here. "delta" is the time since last render in seconds.
//    }
//
//    @Override
//    public void resize(int width, int height) {
//        // Resize your screen here. The parameters represent the new window size.
//    }
//
//    @Override
//    public void pause() {
//        // Invoked when your application is paused.
//    }
//
//    @Override
//    public void resume() {
//        // Invoked when your application is resumed after pause.
//    }
//
//    @Override
//    public void hide() {
//        // This method is called when another screen replaces this one.
//    }
//
//    @Override
//    public void dispose() {
//        // Destroy screen's assets here.
//    }
//}








package io.github.AngryBirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;


import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

/** First screen of the application. Displayed after the application is created. */
public class FirstScreen implements Screen {
    private Game game;
    private Skin skin;
    private Stage stage;

    public FirstScreen(Game game, Skin skin) {
        this.game = game;
        this.skin = skin;
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        // Button to transition to the LevelSelectionScreen
        TextButton startButton = new TextButton("Start Game", skin);
        startButton.setPosition(300, 200);
        startButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LevelSelectionScreen(game, skin)); //  Navigate to LevelSelectionScreen
            }
        });
        stage.addActor(startButton);
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        stage.dispose();
    }
}
