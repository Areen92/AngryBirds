package io.github.AngryBirds;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

public class GameUI extends InputAdapter {
    private Stage stage;
    private boolean isMusicOn = true;
    private int currentPage = 1;
    private final int totalPages = 6; // 90 levels / 15 levels per page

    public GameUI(Stage stage) {
        this.stage = stage;
        Skin skin = new Skin(Gdx.files.internal("uiskin.json")); // replace with your skin file

        createHomeButton(skin);
        createPlayButton(skin);
        createMusicButton(skin);
        createForwardButton(skin);
        createBackwardButton(skin);
        createRetryButton(skin);
        createNextButton(skin);

        // Set GameUI as the input processor to handle keyboard inputs
        Gdx.input.setInputProcessor(this);
    }


    //1) Home button: pressing "H" on keyboard will take the user to homepage
    private void createHomeButton(Skin skin) {
        Button homeButton = new TextButton("Home", skin);
        homeButton.setPosition(50, 500);
        homeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToHomePage();
            }
        });
        stage.addActor(homeButton);
    }



    //2) Play button: pressing "SPACE" will take the user to page where Levels are shown
    private void createPlayButton(Skin skin) {
        Button playButton = new TextButton("Play", skin);
        playButton.setPosition(50, 400);
        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToLevelSelectionPage();
            }
        });
        stage.addActor(playButton);
    }



    //3) Music button: pressing "M" will toggle music on and off
    private void createMusicButton(Skin skin) {
        Button musicButton = new TextButton("Music", skin);
        musicButton.setPosition(50, 300);
        musicButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                toggleMusic();
            }
        });
        stage.addActor(musicButton);
    }




    //4) "forward" and "backward" buttons: if there are 90 levels in the game and 1 level page shows only 15 levels
    // then user is able to move from 1 page to next.
    // pressing right arrow key takes user to next page (1 tap = next page, if 1 tap on the last page then it takes user to 1st page)
    // whereas pressing left arrow key takes user to previous page( 1tap = 1 page back, if 1 tap on first page then it takes user to last page)

    private void createForwardButton(Skin skin) {
        Button forwardButton = new TextButton(">", skin);
        forwardButton.setPosition(600, 100);
        forwardButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToNextPage();
            }
        });
        stage.addActor(forwardButton);
    }

    private void createBackwardButton(Skin skin) {
        Button backButton = new TextButton("<", skin);
        backButton.setPosition(400, 100);
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToPreviousPage();
            }
        });
        stage.addActor(backButton);
    }



    //5) Retry button: if user presses "R" on keyboard This button will be used by user to restart the level if they win/lose the level

    private void createRetryButton(Skin skin) {
        Button retryButton = new TextButton("Retry", skin);
        retryButton.setPosition(50, 200);
        retryButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                retryLevel();
            }
        });
        stage.addActor(retryButton);
    }




    //6) Next button: if user presses "Enter" on keyboard, this button will be used by user to go to next level once the present level has been completed

    private void createNextButton(Skin skin) {
        Button nextButton = new TextButton("Next", skin);
        nextButton.setPosition(50, 100);
        nextButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToNextLevel();
            }
        });
        stage.addActor(nextButton);
    }

    // Keyboard input and their actions
    @Override
    public boolean keyDown(int keycode) {
        switch (keycode) {
            case Input.Keys.H:
                goToHomePage();
                break;
            case Input.Keys.SPACE:
                goToLevelSelectionPage();
                break;
            case Input.Keys.M:
                toggleMusic();
                break;
            case Input.Keys.RIGHT:
                goToNextPage();
                break;
            case Input.Keys.LEFT:
                goToPreviousPage();
                break;
            case Input.Keys.R:
                retryLevel();
                break;
            case Input.Keys.ENTER:
                goToNextLevel();
                break;
        }
        return true;
    }




    private void goToHomePage() {
        System.out.println("Going to Home Page");
        //----------------------------------------------------
    }


    private void goToLevelSelectionPage() {
        System.out.println("Going to Level Selection Page");
        //---------------------------------------------------


    }



    private void toggleMusic() {
        isMusicOn = !isMusicOn;
        if (isMusicOn) {
            System.out.println("Music On");
            // --------------------------------------------
        } else {
            System.out.println("Music Off");
            // ---------------------------------------------
        }
    }



    private void goToNextPage() {
        if (currentPage < totalPages) {
            currentPage++;
        } else {
            currentPage = 1; // Goes back to first page
        }
        System.out.println("Loading Page " + currentPage);
        loadLevelPage(currentPage);
    }





    private void goToPreviousPage() {
        if (currentPage > 1) {
            currentPage--;
        } else {
            currentPage = totalPages; // Goes back to last page
        }
        System.out.println("Loading Page " + currentPage);
        loadLevelPage(currentPage);
    }

    private void loadLevelPage(int page) {
        System.out.println("Loading levels for page: " + page);
        // ---------------------------------------------------------------
    }

    private void retryLevel() {
        System.out.println("Retrying Level");
        // ---------------------------------------------------------
    }

    private void goToNextLevel() {
        System.out.println("Going to Next Level");
        // ---------------------------------------------------------
    }
}
