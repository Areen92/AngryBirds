package io.github.AngryBirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

public class LevelScreen implements Screen {
    private Stage stage;
    private Game game;
    private int level;
    private Skin skin;
    private boolean isMissionComplete = false;
    private boolean isMissionFailed = false;

    public LevelScreen(Game game, int level, Skin skin) {
        this.game = game;
        this.level = level;
        this.skin = skin;
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        setupUI();

        // Keyboard input handling for navigation options
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean keyDown(int keycode) {
                if (isMissionComplete) {
                    handleMissionCompleteKey(keycode);
                } else if (isMissionFailed) {
                    handleMissionFailedKey(keycode);
                }
                return true;
            }
        });
    }

    private void setupUI() {
        // Retry button to restart the level
        TextButton retryButton = new TextButton("Retry", skin);
        retryButton.setPosition(50, 100);
        retryButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                retryLevel();
            }
        });
        stage.addActor(retryButton);

        // Next button to go to the next level
        TextButton nextButton = new TextButton("Next", skin);
        nextButton.setPosition(150, 100);
        nextButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToNextLevel();
            }
        });
        stage.addActor(nextButton);

        // Home button to navigate back to the home page
        TextButton homeButton = new TextButton("Home", skin);
        homeButton.setPosition(250, 100);
        homeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToHomePage();
            }
        });
        stage.addActor(homeButton);

        // Button to go back to level selection screen
        TextButton levelSelectButton = new TextButton("Levels", skin);
        levelSelectButton.setPosition(350, 100);
        levelSelectButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                goToLevelSelectionScreen();
            }
        });
        stage.addActor(levelSelectButton);
    }

    // Key handling for mission complete navigation options
    private void handleMissionCompleteKey(int keycode) {
        switch (keycode) {
            case Input.Keys.H:
                goToHomePage();
                break;
            case Input.Keys.R:
                retryLevel();
                break;
            case Input.Keys.L:
                goToLevelSelectionScreen();
                break;
            case Input.Keys.N:
                goToNextLevel();
                break;
        }
    }

    // Key handling for mission failed navigation options
    private void handleMissionFailedKey(int keycode) {
        switch (keycode) {
            case Input.Keys.H:
                goToHomePage();
                break;
            case Input.Keys.R:
                retryLevel();
                break;
            case Input.Keys.L:
                goToLevelSelectionScreen();
                break;
        }
    }

    private void goToHomePage() {
        System.out.println("Navigating to Home Page");
        game.setScreen(new FirstScreen(game, skin)); // --------------------------------------
        // Replace with actual home screen
    }

    private void retryLevel() {
        System.out.println("Retrying Level " + level);
        game.setScreen(new LevelScreen(game, level, skin)); // Reloads the current level
    }

    private void goToNextLevel() {
        System.out.println("Going to Next Level: " + (level + 1));
        game.setScreen(new LevelScreen(game, level + 1, skin)); // Goes to the next level
    }

    private void goToLevelSelectionScreen() {
        System.out.println("Navigating to Level Selection Screen");
        game.setScreen(new LevelSelectionScreen(game, skin)); // Switches to LevelSelectionScreen
    }

    // Method to show mission completion options
    public void showMissionCompleteDialog() {
        isMissionComplete = true;
        Dialog missionCompleteDialog = new Dialog("Mission Complete!", skin);
        missionCompleteDialog.text("Congratulations! Choose your next action:");
        missionCompleteDialog.button("Home", "home");
        missionCompleteDialog.button("Retry", "retry");
        missionCompleteDialog.button("Levels", "levels");
        missionCompleteDialog.button("Next Level", "next");
        missionCompleteDialog.show(stage);

        missionCompleteDialog.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                switch (missionCompleteDialog.getResult().toString()) {
                    case "home":
                        goToHomePage();
                        break;
                    case "retry":
                        retryLevel();
                        break;
                    case "levels":
                        goToLevelSelectionScreen();
                        break;
                    case "next":
                        goToNextLevel();
                        break;
                }
            }
        });
    }

    // Method to show mission failure options
    public void showMissionFailedDialog() {
        isMissionFailed = true;
        Dialog missionFailedDialog = new Dialog("Mission Failed", skin);
        missionFailedDialog.text("Try again or choose another action:");
        missionFailedDialog.button("Home", "home");
        missionFailedDialog.button("Retry", "retry");
        missionFailedDialog.button("Levels", "levels");
        missionFailedDialog.show(stage);

        missionFailedDialog.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                switch (missionFailedDialog.getResult().toString()) {
                    case "home":
                        goToHomePage();
                        break;
                    case "retry":
                        retryLevel();
                        break;
                    case "levels":
                        goToLevelSelectionScreen();
                        break;
                }
            }
        });
    }

    @Override
    public void render(float delta) {
        stage.act(delta);
        stage.draw();

        // Here we would have logic to check mission status
        // If mission is complete, call showMissionCompleteDialog()
        // If mission is failed, call showMissionFailedDialog()
    }

    //  Required screen lifecycle methods
    @Override
    public void show() {}
    @Override
    public void resize(int width, int height) {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
    @Override
    public void dispose() {
        stage.dispose();
    }
}
