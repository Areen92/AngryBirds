package io.github.AngryBirds;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

public class LevelSelectionScreen implements Screen {
    private Stage stage;
    private Game game;
    private Skin skin;
    private int currentPage = 1;
    private final int totalPages = 6; // 90 levels / 15 levels per page

    public LevelSelectionScreen(Game game, Skin skin) {
        this.game = game;
        this.skin = skin;
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        // Create UI elements
        createLevelButtons();
        createNavigationButtons();
    }

    private void createLevelButtons() {
        int levelsPerPage = 15;
        int startLevel = (currentPage - 1) * levelsPerPage + 1;
        int endLevel = startLevel + levelsPerPage - 1;

        for (int i = startLevel; i <= endLevel; i++) {
            TextButton levelButton = new TextButton("Level " + i, skin);
            levelButton.setPosition(100 * ((i - 1) % 5), 500 - ((i - 1) / 5) * 100); // Adjusted positioning logic
            final int level = i;
            levelButton.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    game.setScreen(new LevelScreen(game, level, skin)); // Transition to selected level
                }
            });
            stage.addActor(levelButton);
        }
    }

    private void createNavigationButtons() {
        Button forwardButton = new TextButton(">", skin);
        forwardButton.setPosition(700, 100);
        forwardButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                nextPage();
            }
        });
        stage.addActor(forwardButton);

        Button backButton = new TextButton("<", skin);
        backButton.setPosition(50, 100);
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                previousPage();
            }
        });
        stage.addActor(backButton);
    }

    private void nextPage() {
        currentPage = (currentPage % totalPages) + 1;
        updateLevelButtons();
    }

    private void previousPage() {
        currentPage = (currentPage == 1) ? totalPages : currentPage - 1;
        updateLevelButtons();
    }

    private void updateLevelButtons() {
        stage.clear(); // Clear existing buttons
        createLevelButtons();
        createNavigationButtons();
    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage); //  Set input processor to handle UI
    }

    @Override
    public void render(float delta) {
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
