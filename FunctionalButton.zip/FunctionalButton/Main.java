//package io.github.AngryBirds;
//
//import com.badlogic.gdx.Game;
//
///** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms.  */
//public class Main extends Game {
//    @Override
//    public void create() {
//        setScreen(new FirstScreen());
//    }
//}





package io.github.AngryBirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {
    private Skin skin;

    @Override
    public void create() {
        skin = new Skin(Gdx.files.internal("uiskin.json")); // Load the skin once here
        setScreen(new FirstScreen(this, skin)); // Pass Main and Skin to FirstScreen
    }

    public Skin getSkin() {
        return skin;
    }
}
